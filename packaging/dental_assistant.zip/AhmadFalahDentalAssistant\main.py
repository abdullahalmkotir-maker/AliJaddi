﻿"""مساعد طبيب الأسنان — تطبيق Streamlit لـ AliJaddi."""
from __future__ import annotations

import streamlit as st

st.set_page_config(page_title="مساعد طبيب الأسنان", layout="wide")
st.title("مساعد طبيب الأسنان")
st.caption("Dental Smart Assistant — AliJaddi model package v1.3.2")
st.success("التثبيت والتشغيل يعملان. طوّر الواجهة والمزامنة في نسختك الكاملة.")
